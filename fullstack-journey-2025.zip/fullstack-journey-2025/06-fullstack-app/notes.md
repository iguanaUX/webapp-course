# Woche 6 Notizen

Hier kannst du deine Notizen zu Woche 6 festhalten.