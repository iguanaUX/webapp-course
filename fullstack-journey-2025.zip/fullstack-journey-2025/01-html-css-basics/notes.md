# Woche 1 Notizen

Hier kannst du deine Notizen zu Woche 1 festhalten.