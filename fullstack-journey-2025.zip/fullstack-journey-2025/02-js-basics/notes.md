# Woche 2 Notizen

Hier kannst du deine Notizen zu Woche 2 festhalten.