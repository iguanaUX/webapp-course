# Woche 4 Notizen

Hier kannst du deine Notizen zu Woche 4 festhalten.